const fetch = require("node-fetch");

exports.handler = async (event) => {
  // Handle preflight request (OPTIONS)
  if (event.httpMethod === "OPTIONS") {
    return {
      statusCode: 200,
      headers: {
        "Access-Control-Allow-Origin": "*",
        "Access-Control-Allow-Headers": "Content-Type",
        "Access-Control-Allow-Methods": "POST, OPTIONS",
      },
      body: "",
    };
  }

  // Extract the chat from the request
  console.log('Event Body:', event.body);
  const chat = JSON.parse(event.body);

  if (!chat || typeof chat !== "object" || Object.keys(chat).length === 0) {
    return {
      statusCode: 400,
      headers: {
        "Access-Control-Allow-Origin": "*",
      },
      body: JSON.stringify({ error: "The chat is empty or undefined" }),
    };
  }

  try {
    // Send the chat to the Llama2 API
    const response = await fetch(
      "http://54.242.252.248:8000/complete-chat/", // Update this to the URL of your Llama2 API
      {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
        },
        body: JSON.stringify(chat),
      }
    );

    const data = await response.json();
    console.log("Llama2 API response:", JSON.stringify(data));

    if (data.error) {
      throw new Error(data.error);
    }

    // Return the Llama2 API response
    return {
      statusCode: 200,
      headers: {
        "Access-Control-Allow-Origin": "*",
      },
      body: JSON.stringify({ assistant: data.assistant }),
    };
  } catch (error) {
    console.error("Error sending chat to Llama2 API:", error);

    return {
      statusCode: 500,
      headers: {
        "Access-Control-Allow-Origin": "*",
      },
      body: JSON.stringify({ error: error.message }),
    };
  }
};
